<?php get_header(); ?>

<main id="main" class="site-main" role="main">
    <?php get_template_part('template-parts/hero-section'); ?>

    <div class="container mx-auto px-6 py-12">
        <?php
        while ( have_posts() ) : the_post();
            the_content();
        endwhile;
        ?>
    </div>
</main>

<?php get_footer(); ?>
